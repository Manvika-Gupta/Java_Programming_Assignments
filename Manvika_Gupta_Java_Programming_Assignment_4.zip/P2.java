import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

public class P2 {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, NumberFormatException, IOException{
Connection conn;
Scanner sc = new Scanner(System.in);
Class.forName("com.mysql.cj.jdbc.Driver");
conn =
DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
System.out.println("Connection with the database successful!!");
System.out.println(conn);
DatabaseMetaData dbm = conn.getMetaData();
Statement st1 = conn.createStatement();
String str = "CREATE TABLE result"+"(rollno int, " +"name varchar(255),"
+"chem int,"+"phys int,"+"maths int,"+"percentage int);";

// check if "employee" table is there
ResultSet tables = dbm.getTables(null, null, "result", null);
if (tables.next())
{
System.out.println("Table already exists");
}
else
{
st1.executeUpdate(str);
System.out.println("Table is created succesfully!!");
} 

System.out.println("How much data you want to insert: ");
int num = sc.nextInt();
while(num!=0){
System.out.println("-------------------------------------------");
System.out.println("Enter the RollNo: ");
int rollno = sc.nextInt();
System.out.println("Enter the Name: ");
String name= sc.next();
System.out.println("Enter Chemistry's Marks: ");
int chem = sc.nextInt();
System.out.println("Enter Physics' Marks: ");
int phys = sc.nextInt();
System.out.println("Enter Maths' Marks: ");
int maths = sc.nextInt();
int percentage = (phys+chem+maths);
PreparedStatement statement2 = conn.prepareStatement("insert into result(rollno, name, chem, phys, maths, percentage)values(?,?,?,?,?,?)");
statement2.setInt(1, rollno);
statement2.setString(2, name);
statement2.setInt(3, chem);
statement2.setInt(4, phys);
statement2.setInt(5, maths);
statement2.setInt(6, percentage);
statement2.executeUpdate();
num--;
}
System.out.println("-------------------------------------------");
System.out.println("Data inserted Successfully...!");
System.out.print("Enter the rollno for marksheet: ");
int roll = sc.nextInt();
sc.close();
PreparedStatement statement3 = conn.prepareStatement("select * from result where rollno = ?");
statement3.setInt(1, roll);

ResultSet marksheet = statement3.executeQuery();
while(marksheet.next())
{
System.out.println("Roll No\t|\tName\t|\tChemistry\t|\tPhysics\t|\tMaths\t|\tPercentage\t|");
System.out.println("--------------------------------------------------------------------------------------------");
System.out.print(marksheet.getInt("rollno")+"\t|\t");
System.out.print(marksheet.getString("name")+"\t|\t");
System.out.print(marksheet.getInt("chem")+"\t\t|\t");
System.out.print(marksheet.getInt("phys")+"\t|\t");
System.out.print(marksheet.getInt("maths")+"\t|\t");
System.out.print(marksheet.getDouble("percentage")+"\t\t|\t");
}
System.out.println();
sc.close();
conn.close();
}
}