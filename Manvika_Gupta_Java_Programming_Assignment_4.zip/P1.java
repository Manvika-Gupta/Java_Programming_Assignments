import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

public class P1 {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, NumberFormatException, IOException{
Connection conn;
Scanner sc = new Scanner(System.in);
Class.forName("com.mysql.cj.jdbc.Driver");
conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
System.out.println("Connection with the database successful!!");
System.out.println(conn);
DatabaseMetaData dbm = conn.getMetaData();
Statement st1 = conn.createStatement();
String str = "CREATE TABLE employee"+"(EId int, " +"Name varchar(255)," +"Age int,"+"Salary int )";
// check if "employee" table is there
ResultSet tables = dbm.getTables(null, null, "employee", null);
if (tables.next())
{
System.out.println("Table aready exist");
}
else
{
st1.executeUpdate(str);
System.out.println("employee table is created!");
}
System.out.println("How much data you want to insert: ");
int num = sc.nextInt();
while(num!=0){
System.out.println("-------------------------------------------");
System.out.println("Enter the ID: ");
int id = sc.nextInt();
System.out.println("Enter the name: ");
String name= sc.next();
System.out.println("Enter age: ");
int age = sc.nextInt();
System.out.println("Enter Salary: ");
int salary = sc.nextInt();
PreparedStatement statement2 = conn.prepareStatement("insert into employee(EId, Name, Age, Salary)values(?,?,?,?)");
statement2.setInt(1, id);
statement2.setString(2, name);
statement2.setInt(3, age);
statement2.setInt(4, salary);
statement2.executeUpdate();
num--;
}
System.out.println("-------------------------------------------");
System.out.println("Data inserted Successfully!!");
sc.close();
conn.close();
}
}






