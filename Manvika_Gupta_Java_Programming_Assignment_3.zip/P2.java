import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class P2 {
public static void main(String[] args) throws IOException {
Scanner sc = new Scanner(System.in);
FileWriter fout = new FileWriter("name.txt");
String inData;
int count = 0;
System.out.println("How many line you want to add: ");
int line = sc.nextInt();
while(line>=0){
inData = sc.nextLine();
fout.write(inData);
fout.write("\n");
line--;
}
fout.close();
FileReader read = new FileReader("name.txt");
Scanner find = new Scanner(read);
String filedata = new String();
while(find.hasNext()){
String data = find.next();
filedata = filedata + data + " ";
if(data.equals("Vatsal")){
count++;
}
}
System.out.println("Number of word changed: "+count);
filedata= filedata.replace("Vatsal", "Vats");
System.out.println("Word Replace Succesfully");
FileWriter fout1 = new FileWriter("name.txt");
fout1.write(filedata);
fout1.close();
find.close();
sc.close(); 
}
}

