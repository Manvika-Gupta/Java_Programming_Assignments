import java.io.*;
import java.util.*;

public class P1
{
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		//Open number.txt file
		FileWriter fout = new FileWriter("number.txt");
		String inData;
		// write number into number.txt file
		System.out.println("How many Numbers do you want to add: ");
		int line = sc.nextInt();
		while(line>0){
		inData = sc.next();
		fout.write(inData);
		fout.write(" ");
		line--;
		}
		fout.close();
		FileReader read = new FileReader("number.txt");
		Scanner find = new Scanner(read);
		FileWriter fodd = new FileWriter("odd.txt");
		FileWriter feven = new FileWriter("even.txt");
		while(find.hasNext()){
		String isOdd = find.next();
		if(Integer.parseInt(isOdd)%2!=0){
		fodd.write(isOdd);
		fodd.write('\n');
		}else if (Integer.parseInt(isOdd)%2==0){
		feven.write(isOdd);
		feven.write('\n');
		}
		}
		find.close();
		fodd.close();
		feven.close();
		sc.close();
		}

}
