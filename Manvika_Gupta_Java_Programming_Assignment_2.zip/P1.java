import java.util.*;

class MyThread1 implements Runnable
{

	@Override
	public void run() {
		int i =1;
		while(i>0){
			System.out.println("thread 1--> hello");
			try {
				Thread.sleep(1000);
			}catch(Exception e) {System.out.println("Error");}

		}
		
	}
}

class MyThread2 implements Runnable
{

	@Override
	public void run() {
		int i =1;
		while(i>0){
			System.out.println("thread 2--> hi");
			try {
				Thread.sleep(3000);
			}catch(Exception e) {System.out.println("Error");}

		}
		
	}

	
	
}

class MyThread3 implements Runnable
{

	@Override
	public void run() {
		
			System.out.println("thread 3-->How are you");
	
	}

	
	
}


public class P1 {

	public static void main(String[] args) {
		MyThread1 a = new MyThread1();
		Thread t1 = new Thread(a);
		MyThread2 b = new MyThread2();
		Thread t2 = new Thread(b);
		MyThread3 c = new MyThread3();
		Thread t3 = new Thread(c);
	
		t1.start();
		t2.start();
		t3.start();
		
	}
	
}
