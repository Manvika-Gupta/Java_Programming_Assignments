import java.util.*;

class Thread1 extends Thread
{
	public void run()
	{
		try {
			
		
		System.out.println("Thread 1 Printing odd numbers: ");
		int i=1;
		while(i<=100)
		{
			
			if(i%2!=0)
			{
				Thread.sleep(200);
			System.out.print(i+" ");
			}
			i++;
		}

			
		}catch(Exception e) {System.out.println("Error");}
	}
	
}
class Thread2 extends Thread
{
	public void run()
	{
		try {
		System.out.println("\nThread 2 Printing even numbers: ");
		int i=1;
		while(i<=100)
		{
			if(i%2==0)
			{
				Thread.sleep(200);
				System.out.print(i+" ");
			}

			i++;
		}
	}catch(Exception e) {System.out.println("Error");}
	
}

}


public class P2 {
	public static void main(String[] args)
	{
		Thread1 t1= new Thread1();
		Thread2 t2 = new Thread2();
		t1.run(); // will first completely run thread1
		t2.run(); // will completely run thread2
	}

}
